#pragma once
#include <vector>
#include <string>

void afficherInt(int* pInt = nullptr);

void afficherTexteStyle(const std::vector<std::string>& tabTexte, const std::vector<std::string>* pStyles = nullptr);
