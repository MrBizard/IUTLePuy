#pragma once

size_t aleatEntreBornes(size_t min, size_t max);

