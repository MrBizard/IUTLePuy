#pragma once

char menu();
