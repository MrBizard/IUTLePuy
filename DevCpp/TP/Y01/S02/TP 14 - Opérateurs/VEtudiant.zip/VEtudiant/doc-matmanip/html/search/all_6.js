var searchData=
[
  ['saisirentier_0',['saisirentier',['../utils_8h.html#ad53dbe8d9be1054eb65f1668cfb83e93',1,'SaisirEntier(int min, int max):&#160;utils.cpp'],['../utils_8cpp.html#ad53dbe8d9be1054eb65f1668cfb83e93',1,'SaisirEntier(int min, int max):&#160;utils.cpp']]],
  ['soustrairematrice_1',['soustrairematrice',['../fonctions_8h.html#a74ca6be257a96599713b7ea33e770aeb',1,'SoustraireMatrice(CMatrice &amp;matA, const CMatrice &amp;matB, const CMatrice &amp;matC):&#160;fonctions.cpp'],['../fonctions_8cpp.html#a74ca6be257a96599713b7ea33e770aeb',1,'SoustraireMatrice(CMatrice &amp;matA, const CMatrice &amp;matB, const CMatrice &amp;matC):&#160;fonctions.cpp']]],
  ['soustrairematrice2_2',['soustrairematrice2',['../fonctions_8h.html#a7aa4eea3a745fe1f3222ddcba56ce272',1,'SoustraireMatrice2(CMatrice &amp;matA, const CMatrice &amp;matB):&#160;fonctions.cpp'],['../fonctions_8cpp.html#a7aa4eea3a745fe1f3222ddcba56ce272',1,'SoustraireMatrice2(CMatrice &amp;matA, const CMatrice &amp;matB):&#160;fonctions.cpp']]]
];
