var searchData=
[
  ['differencematrice_0',['differencematrice',['../fonctions_8h.html#a11b7f4927ce6cf6de2b8040fdbf7f959',1,'DifferenceMatrice(const CMatrice &amp;matA, const CMatrice &amp;matB):&#160;fonctions.cpp'],['../fonctions_8cpp.html#a11b7f4927ce6cf6de2b8040fdbf7f959',1,'DifferenceMatrice(const CMatrice &amp;matA, const CMatrice &amp;matB):&#160;fonctions.cpp']]]
];
