var searchData=
[
  ['affichermatrice_0',['affichermatrice',['../fonctions_8h.html#ae983c1b616a93660fa57b4caf1b75f44',1,'AfficherMatrice(const CMatrice &amp;mat):&#160;fonctions.cpp'],['../fonctions_8cpp.html#ae983c1b616a93660fa57b4caf1b75f44',1,'AfficherMatrice(const CMatrice &amp;mat):&#160;fonctions.cpp']]],
  ['ajoutermatrice_1',['ajoutermatrice',['../fonctions_8h.html#acfe589cb9d180cd43d4fa87c171c3248',1,'AjouterMatrice(CMatrice &amp;matA, const CMatrice &amp;matB, const CMatrice &amp;matC):&#160;fonctions.cpp'],['../fonctions_8cpp.html#acfe589cb9d180cd43d4fa87c171c3248',1,'AjouterMatrice(CMatrice &amp;matA, const CMatrice &amp;matB, const CMatrice &amp;matC):&#160;fonctions.cpp']]],
  ['ajoutermatrice2_2',['ajoutermatrice2',['../fonctions_8h.html#aa1a2683f3a5933c21aed95d1f04a5543',1,'AjouterMatrice2(CMatrice &amp;matA, const CMatrice &amp;matB):&#160;fonctions.cpp'],['../fonctions_8cpp.html#aa1a2683f3a5933c21aed95d1f04a5543',1,'AjouterMatrice2(CMatrice &amp;matA, const CMatrice &amp;matB):&#160;fonctions.cpp']]]
];
