/*!
 *
 * \brief Déclaration de la classe CMatrice. 
 *
 * \author Benjamin ALBOUY-KISSI
 * \date 2009-2015
 * \version 1.1
 */
