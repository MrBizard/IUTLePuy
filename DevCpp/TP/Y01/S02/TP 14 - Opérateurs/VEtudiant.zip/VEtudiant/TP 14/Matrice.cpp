/*!
 *
 * \brief Définition de la classe CMatrice.
 *
 * \author Benjamin ALBOUY-KISSI
 * \date 2009-2017
 * \version 1.1
 */
#include "Matrice.h"
