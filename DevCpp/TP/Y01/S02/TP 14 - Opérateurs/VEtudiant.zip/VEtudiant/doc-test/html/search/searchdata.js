var indexSectionsWithContent =
{
  0: "befhnt",
  1: "t",
  2: "befhnt"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Macros"
};

