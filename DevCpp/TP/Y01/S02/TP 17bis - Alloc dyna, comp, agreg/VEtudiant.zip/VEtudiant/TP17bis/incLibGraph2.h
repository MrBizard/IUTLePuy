#pragma once
#define LIBGRAPH2_LEVEL 4
#define NOMINMAX
#include <LibGraph2.h>
