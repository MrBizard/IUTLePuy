var searchData=
[
  ['setstepduration_0',['SetStepDuration',['../class_c_g_u_i.html#a615adf6a35c0aa1c01d4cb3dcd236ee3',1,'CGUI']]],
  ['simulation_1',['Simulation',['../class_c_g_u_i.html#a0f4d73272d755eb5f0d234e42a049737',1,'CGUI']]],
  ['size_2',['Size',['../class_c_petri_dish.html#a49d6ad4226a74cdccfbab998943ba9b8',1,'CPetriDish']]],
  ['stepduration_3',['StepDuration',['../class_c_g_u_i.html#add9cfd21bf19fea3dcdae252c3958d33',1,'CGUI']]]
];
