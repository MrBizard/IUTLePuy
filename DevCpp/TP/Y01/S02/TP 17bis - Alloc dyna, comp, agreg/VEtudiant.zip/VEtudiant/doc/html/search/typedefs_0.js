var searchData=
[
  ['petri_5fcollection_0',['petri_collection',['../class_c_petri_dish.html#a6ea333e9df1856a2f8624be10c1c290f',1,'CPetriDish']]]
];
