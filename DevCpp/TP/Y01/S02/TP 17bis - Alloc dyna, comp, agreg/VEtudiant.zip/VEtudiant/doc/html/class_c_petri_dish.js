var class_c_petri_dish =
[
    [ "petri_collection", "class_c_petri_dish.html#a6ea333e9df1856a2f8624be10c1c290f", null ],
    [ "CPetriDish", "class_c_petri_dish.html#ae368122e6f168e0fd1079d5d31c46bf9", null ],
    [ "CleanMe", "class_c_petri_dish.html#a4821ee4f73865e98d80837911788f7bb", null ],
    [ "CreateSnapshot", "class_c_petri_dish.html#a3a38d2a77536ca0aa29df5dc371fba79", null ],
    [ "ForceAlive", "class_c_petri_dish.html#a955ddb6a9d5b4729a59e8c022b5c3ac0", null ],
    [ "ForceDead", "class_c_petri_dish.html#a63da05835fb0a954ea2f46c784182fa1", null ],
    [ "IsAlive", "class_c_petri_dish.html#a208a8e45d9d3941cea1b73828c432b3f", null ],
    [ "NbAliveNeighboors", "class_c_petri_dish.html#ade7dcaf9afc34ba8b1fd0cac12cc79d1", null ],
    [ "Size", "class_c_petri_dish.html#a49d6ad4226a74cdccfbab998943ba9b8", null ],
    [ "Update", "class_c_petri_dish.html#a7726ca949f86a3133a005afaec6f6c2b", null ],
    [ "m_cells", "class_c_petri_dish.html#ade9efaf457968c560bc7095eff8c3701", null ]
];