var searchData=
[
  ['isadult_0',['IsAdult',['../class_c_cell.html#a7001d0b7bae349b7277d80f708da9fa2',1,'CCell']]],
  ['isalive_1',['IsAlive',['../class_c_petri_dish.html#a208a8e45d9d3941cea1b73828c432b3f',1,'CPetriDish']]],
  ['isdying_2',['IsDying',['../class_c_cell.html#a6d482793ec7493daa0a6c55ff070cb0b',1,'CCell']]],
  ['isnascent_3',['IsNascent',['../class_c_cell.html#a43a446bf24ffeb9eb24838222da3d68c',1,'CCell']]]
];
