var searchData=
[
  ['nascent_0',['Nascent',['../class_c_cell.html#a470ea35b24feea827593a24a74bcf90ba7dec6ea45370e35056d5a595d959e010',1,'CCell']]]
];
