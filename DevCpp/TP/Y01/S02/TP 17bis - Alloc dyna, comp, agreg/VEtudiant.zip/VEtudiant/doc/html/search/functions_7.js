var searchData=
[
  ['nbaliveneighboors_0',['NbAliveNeighboors',['../class_c_petri_dish.html#ade7dcaf9afc34ba8b1fd0cac12cc79d1',1,'CPetriDish']]]
];
