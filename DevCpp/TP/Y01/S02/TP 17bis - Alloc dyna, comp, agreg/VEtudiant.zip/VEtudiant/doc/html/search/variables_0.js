var searchData=
[
  ['m_5fbinitmode_0',['m_bInitMode',['../class_c_g_u_i.html#a6292a7612c464e616b24b540551c5f10',1,'CGUI']]],
  ['m_5fcells_1',['m_cells',['../class_c_petri_dish.html#ade9efaf457968c560bc7095eff8c3701',1,'CPetriDish']]],
  ['m_5flasttick_2',['m_lastTick',['../class_c_g_u_i.html#ade1d8506e951c54ba56f9087c59e7147',1,'CGUI']]],
  ['m_5fpetridish_3',['m_PetriDish',['../class_c_g_u_i.html#afcdfd886439897ae8fdca014811f2d33',1,'CGUI']]],
  ['m_5fplibgraph2_4',['m_pLibgraph2',['../class_c_g_u_i.html#a70ef62c3a498585fc6a5363ac1fc53c5',1,'CGUI']]],
  ['m_5fstage_5',['m_Stage',['../class_c_cell.html#a9d922026238a615af3d39dc658f0a9e8',1,'CCell']]],
  ['m_5fstepduration_6',['m_StepDuration',['../class_c_g_u_i.html#acd3e33dce256d8f5f25b2498b5fb9390',1,'CGUI']]],
  ['m_5fszcellsize_7',['m_szCellSize',['../class_c_g_u_i.html#a4cc842fefc75f53c5fb606b6883bed5d',1,'CGUI']]]
];
