var searchData=
[
  ['getbounds_0',['GetBounds',['../class_c_forme.html#ac6ab16e616382bfc293d1e605cf90603',1,'CForme']]],
  ['getcolor_1',['GetColor',['../class_c_forme.html#a7acd2ea487dbb14b338861b3174da086',1,'CForme']]],
  ['getfillcolor_2',['GetFillColor',['../class_c_forme.html#aee1ec7aba4aaeb75747be72621ab7d5e',1,'CForme']]],
  ['getstyle_3',['GetStyle',['../class_c_forme.html#a43e4acb8a1a8f635ec57363c8b788024',1,'CForme']]],
  ['getthickness_4',['GetThickness',['../class_c_forme.html#a6d13c5e627b6c7f38de7c1815afaf134',1,'CForme']]],
  ['guisetdefaultfill_5',['GuiSetDefaultFill',['../class_c_t_p.html#ab11c412452a5f6cba1549d1a83a819ca',1,'CTP']]],
  ['guisetdefaultstyle_6',['GuiSetDefaultStyle',['../class_c_t_p.html#a3480a5dce3c5a93248bd0959f6ce77d3',1,'CTP']]]
];
