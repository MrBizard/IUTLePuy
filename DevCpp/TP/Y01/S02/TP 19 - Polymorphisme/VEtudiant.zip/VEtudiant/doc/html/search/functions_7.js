var searchData=
[
  ['setcolor_0',['SetColor',['../class_c_forme.html#af6b05ee4e96a6c622cfc207b56054532',1,'CForme']]],
  ['setfillcolor_1',['SetFillColor',['../class_c_forme.html#a0e495b76886d8365189d36f8efc9367b',1,'CForme']]],
  ['setp1_2',['SetP1',['../class_c_forme.html#a4ecd3f87e95fbeb405a023052f9163c2',1,'CForme']]],
  ['setp2_3',['SetP2',['../class_c_forme.html#aef2f14f993d9099cd3199e2ddcb71777',1,'CForme']]],
  ['setstyle_4',['SetStyle',['../class_c_forme.html#ae9401bcf3b25424abb13c577583055fb',1,'CForme']]],
  ['setthickness_5',['SetThickness',['../class_c_forme.html#ac3455897063e1fbb2e277a9d2ba6364f',1,'CForme']]]
];
