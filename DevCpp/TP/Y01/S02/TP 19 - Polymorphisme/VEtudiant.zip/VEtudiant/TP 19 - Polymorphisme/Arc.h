/*!
 * \file  "Arc.h"
 *
 * \brief Declares the arc class. 
 *
 *
 * \todo Déclarer dans ce fichier la classe CArc
 */
#pragma once
#include "forme.h"

