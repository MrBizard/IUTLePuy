/*!
 * \file  "Ellipse.h"
 *
 * \brief Declares the ellipse class. 
 *
 *
 * \todo Déclarer dans ce fichier la classe CEllipse
 */
#pragma once
#include "forme.h"

