var searchData=
[
  ['help_5fverif_5fimp_0',['HELP_VERIF_IMP',['../test_8h.html#a30964a2a4580580c872258bd20eaeb41',1,'test.h']]]
];
