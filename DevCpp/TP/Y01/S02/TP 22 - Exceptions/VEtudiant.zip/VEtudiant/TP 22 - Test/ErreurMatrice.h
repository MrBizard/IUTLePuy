/*!
 * \file  "ErreurMatrice.h"
 *
 * \brief Déclaration de la classe CErreurMatrice. 
 *
 * \author Benjamin ALBOUY-KISSI
 * \date 2016
 *
 * \todo Déclarer dans le fichier ErreurMatrice.h la classe CErreurMatrice
 */
