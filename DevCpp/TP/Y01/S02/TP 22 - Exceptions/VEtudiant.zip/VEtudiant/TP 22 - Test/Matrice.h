/*!\todo
 * 1) Copiez ici le contenu du fichier Matrice.h du TP 9, puis modifiez la classe 
 * de sorte à ajouter la gestion d'erreurs.\n
 */
/*!
 * \file  "Matrice.h"
 *
 * \brief Déclaration de la classe CMatrice. 
 *
 */
