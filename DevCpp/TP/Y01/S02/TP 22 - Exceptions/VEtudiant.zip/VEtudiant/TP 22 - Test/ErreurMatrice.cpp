/*!
 * \file  "ErreurMatrice.cpp"
 *
 * \brief Définition de la classe CErreurMatrice. 
 *
 * \author Benjamin ALBOUY-KISSI
 * \date 2016
 *
 * \todo Définir dans le fichier ErreurMatrice.cpp la classe CErreurMatrice
 */
#include "StdAfx.h"
