========================================================================
    APPLICATION WIN32 : Vue d'ensemble du projet LibGraph2TestPixels
========================================================================

AppWizard a créé cette application LibGraph2TestPixels pour vous.

Ce fichier contient un résumé des éléments contenus dans chaque fichier qui
constitue votre application LibGraph2TestPixels.


LibGraph2TestPixels.vcxproj
    Il s'agit du fichier projet principal pour les projets VC++ générés à 
    l'aide d'un Assistant Application.
    Il contient des informations relatives à la version de Visual C++ qui a 
    généré le fichier, ainsi que des informations sur les plateformes, 
    configurations et fonctionnalités du projet que vous avez sélectionnées dans
    l'Assistant Application.

LibGraph2TestPixels.vcxproj.filters
    Il s'agit du fichier de filtres pour les projets VC++ générés à l'aide d'un 
    Assistant Application. 
    Il contient des informations sur l'association entre les fichiers de votre 
    projet et les filtres. Cette association est utilisée dans l'IDE pour 
    afficher le regroupement des fichiers qui ont des extensions similares sous 
    un nœud spécifique (par exemple, les fichiers ".cpp" sont associés au 
    filtre "Fichiers sources").

LibGraph2TestPixels.cpp
    Il s'agit du fichier source principal de l'application.

/////////////////////////////////////////////////////////////////////////////
AppWizard a créé les ressources suivantes :

LibGraph2TestPixels.rc
    Il s'agit de la liste de toutes les ressources Microsoft Windows utilisées 
    par le programme. Il inclut les icônes, les bitmaps et les curseurs qui 
    sont stockés dans le sous-répertoire RES. Ce fichier peut être directement 
    modifié dans Microsoft Visual C++.

Resource.h
    Il s'agit du ficher d'en-tête standard, qui définit les nouveaux ID de 
    ressources.
    Microsoft Visual C++ lit et met à jour ce fichier.

LibGraph2TestPixels.ico
    Il s'agit d'un fichier icône, qui est utilisé comme icône de l'application 
    (32x32).
    Cette icône est incluse par le fichier de ressources principal 
    LibGraph2TestPixels.rc.

small.ico
    Il s'agit d'un fichier icône qui contient une version plus petite (16x16)
    de l'icône de l'application. Cette icône est incluse par le fichier de 
    ressources principal LibGraph2TestPixels.rc.

/////////////////////////////////////////////////////////////////////////////
Autres fichiers standard :

StdAfx.h, StdAfx.cpp
    Ces fichiers sont utilisés pour générer un fichier d'en-tête précompilé 
    (PCH) nommé LibGraph2TestPixels.pch et un fichier de types précompilés 
    nommé StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Autres remarques :

AppWizard utilise des commentaires "TODO:" pour indiquer les parties du code 
source où vous devrez ajouter ou modifier du code.

/////////////////////////////////////////////////////////////////////////////
