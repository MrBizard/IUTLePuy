var searchData=
[
  ['déchirement_0',['2.1.2.3 Matrices de déchirement',['../index.html#sec2_1_2_3',1,'']]],
  ['d’agrandissement_20réduction_1',['2.1.2.2 Matrices d’agrandissement / réduction',['../index.html#sec2_1_2_2',1,'']]],
  ['dans_20un_20cas_20réel_2',['TP 09 – Exercice 2    Utilisation de la classe CMatrice dans un cas réel',['../index.html',1,'']]],
  ['de_20déchirement_3',['2.1.2.3 Matrices de déchirement',['../index.html#sec2_1_2_3',1,'']]],
  ['de_20la_20classe_20cmatrice_20dans_20un_20cas_20réel_4',['TP 09 – Exercice 2    Utilisation de la classe CMatrice dans un cas réel',['../index.html',1,'']]],
  ['de_20la_20structure_20du_20programme_5',['2.2 Présentation de la structure du programme',['../index.html#sec2_2',1,'']]],
  ['de_20maths…_6',['2.1.1 Un peu de maths…',['../index.html#sec2_1_1',1,'']]],
  ['de_20rotation_7',['2.1.2.1 Matrices de rotation',['../index.html#sec2_1_2_1',1,'']]],
  ['decreaseangle_8',['DecreaseAngle',['../class_c_t_p.html#a959be7ae9782156b3546f437a7c94bef',1,'CTP']]],
  ['decreasescalex_9',['DecreaseScaleX',['../class_c_t_p.html#aad9cc902263042eb42acf220e629614b',1,'CTP']]],
  ['decreasescaley_10',['DecreaseScaleY',['../class_c_t_p.html#a9e6c052e77a7c083eacb53aa4f5056a3',1,'CTP']]],
  ['decreasetearx_11',['DecreaseTearX',['../class_c_t_p.html#af86061f892e364e6bce089fd50a25730',1,'CTP']]],
  ['decreaseteary_12',['DecreaseTearY',['../class_c_t_p.html#aca4712d37ac9aeb89dc84dafb68deec0',1,'CTP']]],
  ['des_20choses_20à_20faire_13',['Liste des choses à faire',['../todo.html',1,'']]],
  ['différentes_20transformations_20considérées_20par_20l’application_14',['2.1.2 Les différentes transformations considérées par l’application',['../index.html#sec2_1_2',1,'']]],
  ['draw_15',['draw',['../class_c_bit_map.html#a2ddcc94a51b4c03ffcf832046a2abbe2',1,'CBitMap::Draw()'],['../class_c_t_p.html#a3d5cf0d8d37b6b17224867eb397c9a16',1,'CTP::Draw()']]],
  ['du_20programme_16',['du programme',['../index.html#sec2_1',1,'2.1 Objectif du programme.'],['../index.html#sec2_2',1,'2.2 Présentation de la structure du programme']]]
];
