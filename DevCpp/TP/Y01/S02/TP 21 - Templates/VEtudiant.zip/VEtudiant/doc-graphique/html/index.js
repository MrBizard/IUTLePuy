var index =
[
    [ "2.1 Objectif du programme.", "index.html#sec2_1", [
      [ "2.1.1 Un peu de maths…", "index.html#sec2_1_1", [
        [ "2.1.1.1 Coordonnées homogènes et transformations géométriques", "index.html#sec2_1_1_1", null ]
      ] ],
      [ "2.1.2 Les différentes transformations considérées par l’application", "index.html#sec2_1_2", [
        [ "2.1.2.1 Matrices de rotation", "index.html#sec2_1_2_1", null ],
        [ "2.1.2.2 Matrices d’agrandissement / réduction", "index.html#sec2_1_2_2", null ],
        [ "2.1.2.3 Matrices de déchirement", "index.html#sec2_1_2_3", null ]
      ] ],
      [ "2.1.3 Transformer une image", "index.html#sec2_1_3", null ]
    ] ],
    [ "2.2 Présentation de la structure du programme", "index.html#sec2_2", [
      [ "2.2.1 La classe CTP (fichiers TP.h et TP.cpp)", "index.html#sec2_2_1", null ],
      [ "2.2.2 La classe CBitMap", "index.html#sec2_2_2", null ]
    ] ],
    [ "2.3 Travail à réaliser", "index.html#sec2_3", [
      [ "2.3.1 Classe CTP", "index.html#sec2_3_1", null ],
      [ "2.3.2 Classe CBitMap", "index.html#sec2_3_2", null ]
    ] ]
];