var searchData=
[
  ['m_5fbmp_0',['m_bmp',['../class_c_t_p.html#ac24e9e36dc85ff8fc60c10e5de7965e9',1,'CTP']]],
  ['m_5fbmptrans_1',['m_bmpTrans',['../class_c_t_p.html#a1dc02b733df17f8e1cbc5fb80e3e72a3',1,'CTP']]],
  ['m_5fdanglerad_2',['m_dAngleRad',['../class_c_t_p.html#a1c7649dcd8868bfd3050f958a99cb1a7',1,'CTP']]],
  ['m_5fnheight_3',['m_nHeight',['../class_c_bit_map.html#af78170228ebbeba714035a65905da079',1,'CBitMap']]],
  ['m_5fnwidth_4',['m_nWidth',['../class_c_bit_map.html#a76173ca8ffd01e720b9340a82ee2e95c',1,'CBitMap']]],
  ['m_5fvpixels_5',['m_vPixels',['../class_c_bit_map.html#a176976a06e65ddbd1e53382d6475e79a',1,'CBitMap']]]
];
