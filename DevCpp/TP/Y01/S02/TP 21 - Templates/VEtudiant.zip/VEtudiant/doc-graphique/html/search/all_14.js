var searchData=
[
  ['tp_2009_20–_20exercice_202_20utilisation_20de_20la_20classe_20cmatrice_20dans_20un_20cas_20réel_0',['TP 09 – Exercice 2    Utilisation de la classe CMatrice dans un cas réel',['../index.html',1,'']]],
  ['tp_20h_20et_20tp_20cpp_1',['2.2.1 La classe CTP (fichiers TP.h et TP.cpp)',['../index.html#sec2_2_1',1,'']]],
  ['tp_2ecpp_2',['TP.cpp',['../_t_p_8cpp.html',1,'']]],
  ['tp_2eh_3',['TP.h',['../_t_p_8h.html',1,'']]],
  ['transform_4',['Transform',['../class_c_bit_map.html#a26cd1ca797b17da835a5d2050c6dda2f',1,'CBitMap']]],
  ['transformations_20considérées_20par_20l’application_5',['2.1.2 Les différentes transformations considérées par l’application',['../index.html#sec2_1_2',1,'']]],
  ['transformations_20géométriques_6',['2.1.1.1 Coordonnées homogènes et transformations géométriques',['../index.html#sec2_1_1_1',1,'']]],
  ['transformer_20une_20image_7',['2.1.3 Transformer une image',['../index.html#sec2_1_3',1,'']]],
  ['travail_20à_20réaliser_8',['2.3 Travail à réaliser',['../index.html#sec2_3',1,'']]]
];
