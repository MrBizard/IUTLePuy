var class_c_bit_map =
[
    [ "CBitMap", "class_c_bit_map.html#a8f51c203ecbf4d8f9a1dee2d7417dab9", null ],
    [ "LoadImagePPM", "class_c_bit_map.html#a209389c5fcdc2072b3d6417668d0bc93", null ],
    [ "Alloc", "class_c_bit_map.html#a97844fc6d9cfe42c8b7210509678b554", null ],
    [ "GetWidth", "class_c_bit_map.html#a2dee2c4ac8d7969e62c2f5c01644d173", null ],
    [ "GetHeight", "class_c_bit_map.html#a382af9c2b40d2b65ad5f8776873fdb85", null ],
    [ "Draw", "class_c_bit_map.html#a2ddcc94a51b4c03ffcf832046a2abbe2", null ],
    [ "Transform", "class_c_bit_map.html#a26cd1ca797b17da835a5d2050c6dda2f", null ],
    [ "m_vPixels", "class_c_bit_map.html#a176976a06e65ddbd1e53382d6475e79a", null ],
    [ "m_nWidth", "class_c_bit_map.html#a76173ca8ffd01e720b9340a82ee2e95c", null ],
    [ "m_nHeight", "class_c_bit_map.html#af78170228ebbeba714035a65905da079", null ]
];