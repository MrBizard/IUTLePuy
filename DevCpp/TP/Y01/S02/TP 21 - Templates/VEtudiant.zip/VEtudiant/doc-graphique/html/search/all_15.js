var searchData=
[
  ['un_20cas_20réel_0',['TP 09 – Exercice 2    Utilisation de la classe CMatrice dans un cas réel',['../index.html',1,'']]],
  ['un_20peu_20de_20maths…_1',['2.1.1 Un peu de maths…',['../index.html#sec2_1_1',1,'']]],
  ['une_20image_2',['2.1.3 Transformer une image',['../index.html#sec2_1_3',1,'']]],
  ['utilisation_20de_20la_20classe_20cmatrice_20dans_20un_20cas_20réel_3',['TP 09 – Exercice 2    Utilisation de la classe CMatrice dans un cas réel',['../index.html',1,'']]]
];
