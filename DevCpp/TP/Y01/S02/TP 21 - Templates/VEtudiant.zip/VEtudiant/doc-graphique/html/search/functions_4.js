var searchData=
[
  ['getheight_0',['GetHeight',['../class_c_bit_map.html#a382af9c2b40d2b65ad5f8776873fdb85',1,'CBitMap']]],
  ['getwidth_1',['GetWidth',['../class_c_bit_map.html#a2dee2c4ac8d7969e62c2f5c01644d173',1,'CBitMap']]]
];
