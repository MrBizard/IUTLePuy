var class_c_t_p =
[
    [ "CTP", "class_c_t_p.html#ab54ff3f8cf900701316e7c97d4110a40", null ],
    [ "ComputeTransform", "class_c_t_p.html#a3af448ee1767df37961cff1089ce037d", null ],
    [ "OpenPPMFile", "class_c_t_p.html#a94c522e092defa47d7f44ac007a3a1c7", null ],
    [ "IncreaseAngle", "class_c_t_p.html#a2f38d14651bbe17003817dd61ef4d6e3", null ],
    [ "DecreaseAngle", "class_c_t_p.html#a959be7ae9782156b3546f437a7c94bef", null ],
    [ "IncreaseScaleX", "class_c_t_p.html#aeee9fd9359b4d8155c2db6f2c65fc1d6", null ],
    [ "DecreaseScaleX", "class_c_t_p.html#aad9cc902263042eb42acf220e629614b", null ],
    [ "IncreaseScaleY", "class_c_t_p.html#a6cc1e377515c8674f1beabfb5f7d4b47", null ],
    [ "DecreaseScaleY", "class_c_t_p.html#a9e6c052e77a7c083eacb53aa4f5056a3", null ],
    [ "IncreaseTearX", "class_c_t_p.html#a64b450b27e087db3ca3ee5dd3b4124fb", null ],
    [ "DecreaseTearX", "class_c_t_p.html#af86061f892e364e6bce089fd50a25730", null ],
    [ "IncreaseTearY", "class_c_t_p.html#a73fb88d0d6b00bd0a2693057b7479655", null ],
    [ "DecreaseTearY", "class_c_t_p.html#aca4712d37ac9aeb89dc84dafb68deec0", null ],
    [ "Draw", "class_c_t_p.html#a3d5cf0d8d37b6b17224867eb397c9a16", null ],
    [ "m_bmp", "class_c_t_p.html#ac24e9e36dc85ff8fc60c10e5de7965e9", null ],
    [ "m_bmpTrans", "class_c_t_p.html#a1dc02b733df17f8e1cbc5fb80e3e72a3", null ],
    [ "m_dAngleRad", "class_c_t_p.html#a1c7649dcd8868bfd3050f958a99cb1a7", null ]
];