var searchData=
[
  ['réaliser_0',['2.3 Travail à réaliser',['../index.html#sec2_3',1,'']]],
  ['réduction_1',['2.1.2.2 Matrices d’agrandissement / réduction',['../index.html#sec2_1_2_2',1,'']]],
  ['réel_2',['TP 09 – Exercice 2    Utilisation de la classe CMatrice dans un cas réel',['../index.html',1,'']]],
  ['rotation_3',['2.1.2.1 Matrices de rotation',['../index.html#sec2_1_2_1',1,'']]]
];
