var searchData=
[
  ['m_5fbmp_0',['m_bmp',['../class_c_t_p.html#ac24e9e36dc85ff8fc60c10e5de7965e9',1,'CTP']]],
  ['m_5fbmptrans_1',['m_bmpTrans',['../class_c_t_p.html#a1dc02b733df17f8e1cbc5fb80e3e72a3',1,'CTP']]],
  ['m_5fdanglerad_2',['m_dAngleRad',['../class_c_t_p.html#a1c7649dcd8868bfd3050f958a99cb1a7',1,'CTP']]],
  ['m_5fnheight_3',['m_nHeight',['../class_c_bit_map.html#af78170228ebbeba714035a65905da079',1,'CBitMap']]],
  ['m_5fnwidth_4',['m_nWidth',['../class_c_bit_map.html#a76173ca8ffd01e720b9340a82ee2e95c',1,'CBitMap']]],
  ['m_5fvpixels_5',['m_vPixels',['../class_c_bit_map.html#a176976a06e65ddbd1e53382d6475e79a',1,'CBitMap']]],
  ['maths…_6',['2.1.1 Un peu de maths…',['../index.html#sec2_1_1',1,'']]],
  ['matrices_20d’agrandissement_20réduction_7',['2.1.2.2 Matrices d’agrandissement / réduction',['../index.html#sec2_1_2_2',1,'']]],
  ['matrices_20de_20déchirement_8',['2.1.2.3 Matrices de déchirement',['../index.html#sec2_1_2_3',1,'']]],
  ['matrices_20de_20rotation_9',['2.1.2.1 Matrices de rotation',['../index.html#sec2_1_2_1',1,'']]]
];
