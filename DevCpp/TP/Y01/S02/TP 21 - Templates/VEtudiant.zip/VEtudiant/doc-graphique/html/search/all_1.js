var searchData=
[
  ['1_201_201_20coordonnées_20homogènes_20et_20transformations_20géométriques_0',['2.1.1.1 Coordonnées homogènes et transformations géométriques',['../index.html#sec2_1_1_1',1,'']]],
  ['1_201_20un_20peu_20de_20maths…_1',['2.1.1 Un peu de maths…',['../index.html#sec2_1_1',1,'']]],
  ['1_202_201_20matrices_20de_20rotation_2',['2.1.2.1 Matrices de rotation',['../index.html#sec2_1_2_1',1,'']]],
  ['1_202_202_20matrices_20d’agrandissement_20réduction_3',['2.1.2.2 Matrices d’agrandissement / réduction',['../index.html#sec2_1_2_2',1,'']]],
  ['1_202_203_20matrices_20de_20déchirement_4',['2.1.2.3 Matrices de déchirement',['../index.html#sec2_1_2_3',1,'']]],
  ['1_202_20les_20différentes_20transformations_20considérées_20par_20l’application_5',['2.1.2 Les différentes transformations considérées par l’application',['../index.html#sec2_1_2',1,'']]],
  ['1_203_20transformer_20une_20image_6',['2.1.3 Transformer une image',['../index.html#sec2_1_3',1,'']]],
  ['1_20classe_20ctp_7',['2.3.1 Classe CTP',['../index.html#sec2_3_1',1,'']]],
  ['1_20la_20classe_20ctp_20fichiers_20tp_20h_20et_20tp_20cpp_8',['2.2.1 La classe CTP (fichiers TP.h et TP.cpp)',['../index.html#sec2_2_1',1,'']]],
  ['1_20objectif_20du_20programme_9',['2.1 Objectif du programme.',['../index.html#sec2_1',1,'']]]
];
