var searchData=
[
  ['transform_0',['Transform',['../class_c_bit_map.html#a26cd1ca797b17da835a5d2050c6dda2f',1,'CBitMap']]]
];
