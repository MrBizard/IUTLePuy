/*!
 * \file  "Matrice.cpp"
 *
 * \brief Définition de la classe CMatrice. 
 *
 *
 * \todo
 * 1) Copiez ici le contenu du fichier Matrice.cpp du TP 2, puis modifiez la classe 
 * de sorte à la rendre générique.\n
 * C'est-à-dire, transformez-là en template dont le paramètre du template sera 
 * le type d'éléments stockés dans la matrice.
 */
#include "StdAfx.h"
