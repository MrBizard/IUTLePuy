/*!\todo
 * 1) Copiez ici le contenu du fichier Matrice.h du TP 2, puis modifiez la classe 
 * de sorte à la rendre générique.\n
 * C'est-à-dire, transformez-là en template dont le paramètre du template sera 
 * le type d'éléments stockés dans la matrice.
 */
/*!
 * \file  "Matrice.h"
 *
 * \brief Déclaration de la classe CMatrice. 
 *
 */
