/*!\file
 * \brief Fichier d'inclusion de LibGraph2 en niveau 4
 * \author Benjamin ALBOUY-KISSI
 */
#define LIBGRAPH2_LEVEL 4
#include <LibGraph2.h>
