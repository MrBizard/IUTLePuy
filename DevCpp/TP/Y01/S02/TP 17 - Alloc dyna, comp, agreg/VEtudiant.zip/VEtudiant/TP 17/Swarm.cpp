/*!\file
 * \brief Définition de la classe CNet
 * \author Benjamin ALBOUY-KISSI
 */
