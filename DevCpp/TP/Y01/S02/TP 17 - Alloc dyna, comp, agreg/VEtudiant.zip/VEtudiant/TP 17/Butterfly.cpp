/*!\file
 * \brief Définition de la classe CButterfly
 * \author Benjamin ALBOUY-KISSI
 */

const double pi = 3.14159265359; //!< C'est PI !
