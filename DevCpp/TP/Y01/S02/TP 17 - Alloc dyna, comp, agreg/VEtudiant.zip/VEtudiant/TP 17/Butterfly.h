/*!\file
 * \brief Déclaration de la classe CButterfly
 * \author Benjamin ALBOUY-KISSI
 */
