/*!\file
 * \brief Déclaration de la classe CSwarm
 * \author Benjamin ALBOUY-KISSI
 */
