var searchData=
[
  ['moveafraidof_0',['MoveAfraidOf',['../class_c_butterfly.html#a7ddd1d04ae015b8464187d53b2b44662',1,'CButterfly']]]
];
