var class_c_net =
[
    [ "butterfliesList", "class_c_net.html#aa0e58a90b065b04f0545e388e162679a", null ],
    [ "AppendButterfly", "class_c_net.html#af1f9e52bc672f4511030f40512886a0a", null ],
    [ "Count", "class_c_net.html#ac9b3ec3066dd1ec7f6738975fba298d2", null ],
    [ "RemoveDead", "class_c_net.html#afdca16773dee153d08689abda2ac4293", null ],
    [ "m_butterflies", "class_c_net.html#aee6d651ed6879f6f16305d6bd5c30568", null ]
];