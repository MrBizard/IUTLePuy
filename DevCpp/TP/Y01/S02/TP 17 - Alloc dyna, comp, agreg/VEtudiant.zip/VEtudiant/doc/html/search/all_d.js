var searchData=
[
  ['removebutterfly_0',['RemoveButterfly',['../class_c_swarm.html#acace938821b12b4f33b6d1c4064110b6',1,'CSwarm']]],
  ['removedead_1',['RemoveDead',['../class_c_net.html#afdca16773dee153d08689abda2ac4293',1,'CNet']]],
  ['removeoutofscreendead_2',['RemoveOutOfScreenDead',['../class_c_swarm.html#a46473ca7127915da6312150e956af37f',1,'CSwarm']]]
];
