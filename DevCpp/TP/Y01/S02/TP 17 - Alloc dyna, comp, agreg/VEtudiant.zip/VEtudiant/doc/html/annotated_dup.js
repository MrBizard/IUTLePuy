var annotated_dup =
[
    [ "CButterfly", "class_c_butterfly.html", "class_c_butterfly" ],
    [ "CNet", "class_c_net.html", "class_c_net" ],
    [ "CSwarm", "class_c_swarm.html", "class_c_swarm" ],
    [ "CVecteur2D", "class_c_vecteur2_d.html", "class_c_vecteur2_d" ]
];