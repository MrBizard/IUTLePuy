var class_c_swarm =
[
    [ "butterfliesList", "class_c_swarm.html#a3d2990add82b1ac64a41e0a04bd2443e", null ],
    [ "CSwarm", "class_c_swarm.html#a93787f59938f1ffbd72f626b2135f408", null ],
    [ "AppendButterfly", "class_c_swarm.html#aa19f6ccb6aca29b468248488116bf1e8", null ],
    [ "getFirst", "class_c_swarm.html#a65038ac259cd8a5233ad62dd45d6cc67", null ],
    [ "getNext", "class_c_swarm.html#a18fd6102fd27e91a41fad5a39dfada6e", null ],
    [ "RemoveButterfly", "class_c_swarm.html#acace938821b12b4f33b6d1c4064110b6", null ],
    [ "RemoveOutOfScreenDead", "class_c_swarm.html#a46473ca7127915da6312150e956af37f", null ],
    [ "m_butterflies", "class_c_swarm.html#a3a169cdb0b5fda7570f17a7c396ab744", null ],
    [ "m_fMaxHeight", "class_c_swarm.html#aa7cb136d7dabed6ccbdd3ac23435510d", null ]
];