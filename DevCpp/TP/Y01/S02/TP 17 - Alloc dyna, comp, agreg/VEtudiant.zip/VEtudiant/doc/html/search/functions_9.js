var searchData=
[
  ['setnorm_0',['setNorm',['../class_c_vecteur2_d.html#a86553bcfee4e343ab96a7c73f0b044f4',1,'CVecteur2D']]],
  ['setorientation_1',['setOrientation',['../class_c_vecteur2_d.html#af5c06cf312a235a06831654586003d14',1,'CVecteur2D']]],
  ['setx_2',['setX',['../class_c_vecteur2_d.html#a7d679559d85c7c97dca36896d5f54388',1,'CVecteur2D']]],
  ['sety_3',['setY',['../class_c_vecteur2_d.html#a84c8026d46ffc74256b9e93beefea713',1,'CVecteur2D']]]
];
