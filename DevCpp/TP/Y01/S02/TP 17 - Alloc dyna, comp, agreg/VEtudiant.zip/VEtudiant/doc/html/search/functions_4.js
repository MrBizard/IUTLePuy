var searchData=
[
  ['isalive_0',['isAlive',['../class_c_butterfly.html#adcec04d10724a76895bdb816ebf202ae',1,'CButterfly']]]
];
