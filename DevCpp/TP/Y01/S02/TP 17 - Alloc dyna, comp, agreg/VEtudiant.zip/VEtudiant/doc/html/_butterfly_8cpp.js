var _butterfly_8cpp =
[
    [ "pi", "_butterfly_8cpp.html#a43016d873124d39034edb8cd164794db", null ]
];