var searchData=
[
  ['appendbutterfly_0',['appendbutterfly',['../class_c_net.html#af1f9e52bc672f4511030f40512886a0a',1,'CNet::AppendButterfly()'],['../class_c_swarm.html#aa19f6ccb6aca29b468248488116bf1e8',1,'CSwarm::AppendButterfly()']]]
];
