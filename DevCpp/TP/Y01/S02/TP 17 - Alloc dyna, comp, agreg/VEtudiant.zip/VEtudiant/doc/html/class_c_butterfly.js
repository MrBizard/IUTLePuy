var class_c_butterfly =
[
    [ "CButterfly", "class_c_butterfly.html#a2c92a9e551efa6776243be9676e9d3de", null ],
    [ "getPos", "class_c_butterfly.html#a291043b5fcd8642874f2f650622c99a8", null ],
    [ "getSpeed", "class_c_butterfly.html#a3cd6839f6994a16a51f9a29125b31986", null ],
    [ "isAlive", "class_c_butterfly.html#adcec04d10724a76895bdb816ebf202ae", null ],
    [ "MoveAfraidOf", "class_c_butterfly.html#a7ddd1d04ae015b8464187d53b2b44662", null ],
    [ "m_nLifeTimeInSec", "class_c_butterfly.html#a17dbd8ca24d0a59ece2f8a218906ef0a", null ],
    [ "m_nViewingDistance", "class_c_butterfly.html#adf30033f555d0c640ae75ed20e9586d4", null ],
    [ "m_ptMax", "class_c_butterfly.html#afb1e27ee073b7aca45e75a1002f7ff68", null ],
    [ "m_ptPos", "class_c_butterfly.html#aba4455e7841891e669ae941ca3b75748", null ],
    [ "m_timeBirth", "class_c_butterfly.html#a4785bd511986a0dc02694a894ac0473f", null ],
    [ "m_timeLastMove", "class_c_butterfly.html#aee3f86c178e578e4b52c21cee6908080", null ],
    [ "m_vSpeed", "class_c_butterfly.html#a9965416bc2071e50b4e6b3b5e29c5a9c", null ]
];