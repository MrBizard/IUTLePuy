var searchData=
[
  ['butterflieslist_0',['butterflieslist',['../class_c_net.html#aa0e58a90b065b04f0545e388e162679a',1,'CNet::butterfliesList'],['../class_c_swarm.html#a3d2990add82b1ac64a41e0a04bd2443e',1,'CSwarm::butterfliesList']]]
];
