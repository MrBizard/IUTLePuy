/*!
 * \file  "Rectangle.h"
 *
 * \brief Declares the rectangle class. 
 *
 *
 * \todo Déclarer dans ce fichier la classe CRect
 */
#pragma once
#include "forme.h"

