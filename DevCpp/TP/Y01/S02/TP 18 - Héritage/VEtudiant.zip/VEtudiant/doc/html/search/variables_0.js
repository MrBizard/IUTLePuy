var searchData=
[
  ['gc_5fdwmaxtime_0',['gc_dwMaxTime',['../inc_lib_graph2_8h.html#a43de55500f8424657d8386e2e23f8958',1,'incLibGraph2.h']]],
  ['gc_5fnimgheight_1',['gc_nImgHeight',['../inc_lib_graph2_8h.html#a16f59feabd31f0aa299e69eedc58f638',1,'incLibGraph2.h']]],
  ['gc_5fnimgwidth_2',['gc_nImgWidth',['../inc_lib_graph2_8h.html#a401d6751d42b5b6629c345ebbd548ef9',1,'incLibGraph2.h']]],
  ['gc_5fnimgyoffset_3',['gc_nImgYOffset',['../inc_lib_graph2_8h.html#a424761974350dcc9ef8192729f0a5408',1,'incLibGraph2.h']]]
];
