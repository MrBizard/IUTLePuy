var inc_lib_graph2_8h =
[
    [ "LIBGRAPH2_LEVEL", "inc_lib_graph2_8h.html#a5ea2ed3634641471fb7962320b1862b2", null ],
    [ "gc_nImgWidth", "inc_lib_graph2_8h.html#a401d6751d42b5b6629c345ebbd548ef9", null ],
    [ "gc_nImgHeight", "inc_lib_graph2_8h.html#a16f59feabd31f0aa299e69eedc58f638", null ],
    [ "gc_nImgYOffset", "inc_lib_graph2_8h.html#a424761974350dcc9ef8192729f0a5408", null ],
    [ "gc_dwMaxTime", "inc_lib_graph2_8h.html#a43de55500f8424657d8386e2e23f8958", null ]
];