var index =
[
    [ "Exercice 1 Présentation", "index.html#sec1", [
      [ "1.1 Objectifs du programme", "index.html#sec1_1", null ],
      [ "1.2 Présentation de la structure du programme", "index.html#sec1_2", [
        [ "1.2.1 La classe CTP (fichiers TP.h et TP.cpp)", "index.html#sec1_2_1", null ],
        [ "1.2.2 La classe CForme (fichiers Forme.h et Forme.cpp)", "index.html#sec1_2_2", null ]
      ] ]
    ] ],
    [ "Exercice 2 Travail à réaliser", "index.html#sec2", [
      [ "2.1 La classe CRect", "index.html#sec2_1", null ],
      [ "2.2 La classe CEllipse", "index.html#sec2_2", null ],
      [ "2.3 La classe CArc", "index.html#sec2_3", null ]
    ] ]
];