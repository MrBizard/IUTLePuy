var searchData=
[
  ['getbounds_0',['GetBounds',['../class_c_forme.html#ac6ab16e616382bfc293d1e605cf90603',1,'CForme']]],
  ['getcolor_1',['GetColor',['../class_c_forme.html#a7acd2ea487dbb14b338861b3174da086',1,'CForme']]],
  ['getstyle_2',['GetStyle',['../class_c_forme.html#a43e4acb8a1a8f635ec57363c8b788024',1,'CForme']]],
  ['getthickness_3',['GetThickness',['../class_c_forme.html#a6d13c5e627b6c7f38de7c1815afaf134',1,'CForme']]],
  ['guisetdefaultstyle_4',['GuiSetDefaultStyle',['../class_c_t_p.html#a3480a5dce3c5a93248bd0959f6ce77d3',1,'CTP']]]
];
