var indexSectionsWithContent =
{
  0: "1_cdfglmptà",
  1: "cmp",
  2: "_",
  3: "g",
  4: "1cdfltà"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Fonctions",
  3: "Variables",
  4: "Pages"
};

