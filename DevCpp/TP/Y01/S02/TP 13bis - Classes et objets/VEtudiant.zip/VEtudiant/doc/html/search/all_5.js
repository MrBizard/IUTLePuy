var searchData=
[
  ['g_5fszcase_0',['g_szCase',['../prog_8cpp.html#a63a25514a6efc23629d18164dc70fd05',1,'prog.cpp']]]
];
