/*!
 * \file "Case.h"
 * Déclaration de la classe CCase
 * 
 * Copyright (c) 2015 by Benjamin ALBOUY-KISSI
 *
 * \todo Déclarez la classe CCase dans le fichier Case.h
 */
