/*!
 * \file "case.cpp"
 * Définition de la classe CCase
 * 
 * Copyright (c) 2015 by Benjamin ALBOUY-KISSI
 *
 * \todo Définissez la classe CCase dans le fichier Case.cpp
 */
