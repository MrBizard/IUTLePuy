/*!
 * \file "Maze.cpp"
 * Définition de la classe CMaze
 * 
 * Copyright (c) 2015 by Benjamin ALBOUY-KISSI
 *
 * \todo Définissez la classe CMaze dans le fichier Maze.cpp
 */
