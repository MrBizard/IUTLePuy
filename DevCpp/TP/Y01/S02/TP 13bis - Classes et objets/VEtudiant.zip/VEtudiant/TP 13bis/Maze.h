/*!
 * \file "Maze.h"
 * Déclaration de la classe CMaze
 * 
 * Copyright (c) 2015 by Benjamin ALBOUY-KISSI
 *
 * \todo Déclarez la classe CMaze dans le fichier Maze.h
 */
